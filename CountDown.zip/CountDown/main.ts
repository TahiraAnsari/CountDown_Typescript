#! /usr/bin/env node

import inquirer from "inquirer";
import { differenceInSeconds} from "date-fns";
const res = await inquirer.prompt(
    {
        name: "userInput",
        message: "Enter the amount of Seconds:",
        type: "number",
        validate: (input)=>{
            if(isNaN(input)){
                return "Please enter a valid number"
            }else if(input > 60){
                return "seconds must be in 60"
            } else{
                return true
            }
        }
    }
);

let input = res.userInput

// let val = res.userInput;
// console.log(val);

function startTime(val:number){
    const initialTime = new Date().setSeconds(new Date().getSeconds()+val)
    const intervalTime = new Date(initialTime);
    setInterval((() =>{
        const currentTime =  new Date()
        const timeDiff = differenceInSeconds(intervalTime, currentTime);

        if(timeDiff <= 0){
            console.log("Timer has Expired");
            process.exit();
        }
        const minute = Math.floor((timeDiff%(3600*24))/3600)
        const sec = Math.floor(timeDiff % 60);
        console.log(`${minute.toString().padStart(2,"0")}:${sec.toString().padStart(2,"0")}`)
    }),1000)
}
startTime(input);